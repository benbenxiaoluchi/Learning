/**
 * Created by booker on 2016/10/21.
 */
'use strict';
factories.factory('personalisedMessageData', function() {
    return {
            allParticipantsList: null,
            checkInList: null,
            checkOutList: null,
            checkInCount: null,
            checkOutCount: null,
            activityID: null,
            groupID:null,
            sendToGroupSelected: '',
            messageBody: '',
            flag: '',
            MessageInfo: [],
            backViewFlag: ''
    };
});