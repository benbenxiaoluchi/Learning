﻿(function () {
    'use strict';
    //angular.module('templates.event.stream', ['js']);
    app.config(function ($stateProvider, $urlRouterProvider) {
        $stateProvider
            .state('app.article', {
                url: "/article/:articleId/:flag",
                views: {
                    'menuContent': {
                        templateUrl: "conLearning/event/trainingDetail/tabs/stream/stream-detail.html",
                        controller: 'streamDetailController'
                    }
                }
            })
            .state('app.discussion', {
                url: "/discussion/:discussionId/:circleId",
                views: {
                    'menuContent': {
                        templateUrl: "conLearning/event/trainingDetail/tabs/stream/discussions-detail.html",
                        controller: "discussionsDetailController"
                    }
                }
            });
    });
})();