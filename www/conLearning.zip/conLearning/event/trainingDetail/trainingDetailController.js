﻿/**
* Created by qiang.shao on 4/27/2015.
*/
//navigator.splashscreen.hide();
'use strict';

controllers.controller('TrainingDetailCtrl',
    ['$scope', '$rootScope', 'trainingService', '$timeout', '$stateParams', '$filter', 'menuService', '$ionicSlideBoxDelegate', '$log', '$ionicLoading', '$ionicHistory', 'authService', '$ionicPlatform', '$ionicModal', '$cordovaToast', '$cordovaClipboard', '$ionicPopup', 'localStorageService', '$cordovaCalendar', 'streamService', '$ionicScrollDelegate', '$cordovaDevice', 'connectedLearning.constants.environments', 'environmentData', '$interval','personalisedMessageData', 'itemPathService',
function ($scope, $rootScope, trainingService, $timeout, $stateParams, filter, menuService, $ionicSlideBoxDelegate, $log, $ionicLoading, $ionicHistory, authService, $ionicPlatform, $ionicModal, $cordovaToast, $cordovaClipboard, $ionicPopup, localStorageService, $cordovaCalendar, streamService, $ionicScrollDelegate, device, envs, environmentData, $interval, personalisedMessageData, itemPathService) {
    var activityId, playabilityValue, sendAllParVisible, currentTrainingFromDt, loginUserID;
    //#region Properties
    $scope.meterials = [];
    $scope.searchInprogress = false;
    $scope.positionPartFlag = 0, $scope.positionFacuFlag = 0, $scope.positionPeopleFlag = 0;
    $scope.participants = [], $scope.faculty = [], $scope.Venue = [], $scope.singleFacility = [], $scope.Schedule = [], $scope.peopleLikeMe = [], $scope.peopleOnSite = [], $scope.weather = [], $scope.demographicType = [], $scope.demographics = [];
    $scope.googleMapVisible = false;
    $scope.allParAddress = '';
    $scope.qCenterLinkVisible = false;
    $scope.currentTemp = 'C';
    $scope.weatherCard = false;
    $scope.sendEmailVisible = false;
    var ImpersonateStatus;
    var par_boolOpenPeopleLikeMe, par_boolPeopleLikeMeShow, par_PeopleLikeMeTitle, par_PeopleLikeMeIcon, par_DemographicTitle, par_boolOpenDemographic, par_boolDemographicShow
        , par_DemographicIcon, par_demographics, par_boolOpenDemographics, par_boolDemographicsShow, par_DemographicsTitle, peo_peopleLikeMe,
        peo_boolOpenPeopleLikeMe, peo_boolPeopleLikeMeShow, peo_PeopleLikeMeTitle, peo_PeopleLikeMeIcon, peo_DemographicTitle, peo_boolOpenDemographic, peo_boolDemographicShow
        , peo_DemographicIcon, peo_demographics, peo_boolOpenDemographics, peo_boolDemographicsShow, peo_DemographicsTitle, par_peopleLikeMe;
    $scope.sessionComments = '';
    $scope.circleTitle = 'Circle';
    //#endregion
    $scope.openSearch = function () {
        $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/search.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.search_modal = modal;
            modal.show();
            //cordova.plugins.Keyboard.show();
        });
        $scope.clearSearch();
    };
    function getRollCall(loginUserID, AuthorIDType, activityId, mockDate) {
        trainingService.getRollCall(loginUserID, AuthorIDType, activityId, mockDate).then(function (data) {
            if (data.Content != '') {
                $scope.sumOfInRoom = data.Content.SumOfInRooms;
                //$scope.sumOfOutRoom = data.Content.SumOfOutRoom + data.Content.NoAction;
                $scope.sumOfOutRoom = data.Content.SumOfOutRoom;
                $scope.sumOfLearners = data.Content.SumOfLearners;
            } else {
                $scope.sumOfInRoom = 0;
                $scope.sumOfOutRoom = 0;
                $scope.sumOfLearners = 0;
            }
        }, function (data) {
            console.log("getRollCall: " + data);
        });
    }
    //display the attendance status and time 
    $scope.sessionId = [];
    $scope.authorId = [];
    if (environmentData.environment !== envs.PROD && environmentData.environment !== envs.DEV) {
        trainingService.getAttendanceStatus($scope.eid, $scope.currentTrainingId, $scope.sessionId).then(function (data) {
            if (data) {
                var attStatus = data.Status[0].AttendanceStatus;
                var attDT = data.Status[0].StatusDT;
                //$scope.statusData = data.StatusDT;
                if (attStatus == 0) {
                    $scope.currentAttendanceStatus = 'No Action';
                } else if (attStatus == 1 || attStatus == 2) {
                    $scope.currentAttendanceStatus = 'Checked in' + ' since ' + filter('date')(new Date(attDT), 'hh:mma');
                } else {
                    $scope.currentAttendanceStatus = 'Checked out' + ' since ' + filter('date')(new Date(attDT), 'hh:mma');
                };
            } else {
                console.log('Attendance API is down.');
            }
        }, function (data) {
            console.log(data);
        });
    }

    $scope.performSearch = function () {
        //alert($scope.searchText);    
        if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "Participants") {
            $scope.Venue = [];
            $scope.noDataShow = false;
            $scope.searchPeople($scope.currentTrainingId, $scope.positionSearchFlag, 1);
        } else if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "People On Site") {
            $scope.Venue = [];
            $scope.noDataShow = false;
            $scope.searchPeopleOnSite($scope.currentTrainingId, $scope.peopleOnSiteSearchPositionFlag);
        };
    }
    $scope.clearSearch = function () {
        $scope.Venue = [];
        $scope.searchText = '';
        $scope.noDataText = '';
        $scope.noDataShow = false;
        $scope.moreVenueData = false;
        $scope.positionSearchFlag = 0;
        $scope.peopleOnSiteSearchPositionFlag = 0;
        cordova.plugins.Keyboard.close();
    }
    $scope.changeSearch = function () {
        if (searchText.length < 3) {
            $scope.canSearch = false;
        } else {
            $scope.canSearch = true;
        }
    }
    $scope.closeSearch = function () {
        $scope.search_modal.hide();
        $scope.clearSearch();
    }

    $scope.navToPeople = function (eid, peopleKey) {
        $scope.navigateToState('app.people', { peopleKey: peopleKey, enterpriseId: eid, tab: 0 }, false)
    }

    $scope.$on("changedTab", function (event, data) {


        // var d = new Date();
        // alert(d.getTime());
        // alert(Date.parse(d)/1000);

        //$scope.showPost = false;
        $scope.tabIndex = data.tab;
        var id = data.id;
        //event.stopPropagation();//prevent the event popup again.
        $scope.participantsflag = false;
        $scope.peopleFlag = false;

        if (sendAllParVisible && data.tabLabel == 'Participants') {
            $scope.sendEmailVisible = true;
        } else {
            $scope.sendEmailVisible = false;
        }

        if (data.tabLabel == 'Schedule') {
            if ($scope.Schedule.length == 0) {
                $scope.getSchedule(activityId, $scope.ScheduleStartDate, $scope.ScheduleStartLocalDate);
            }
        } else if (data.tabLabel == 'Participants') {
            saveDropdownValue(4);
            restoreDropdownValue(2);
            $scope.initializeDropdownValue();
            $scope.getDemographicType('1');
            $scope.getPeopleLikeMe($rootScope.peoplekey, activityId, 1);

            if ($scope.participants.length == 0) {
                $scope.getParticipants(activityId, $scope.positionPartFlag, '', '');
            }
            $scope.allParAddress = '';
            $scope.getAllParEmail();
        } else if (data.tabLabel == 'Presenters') {
            if ($scope.faculty.length == 0) {
                $scope.getFaculty(activityId, $scope.positionFacuFlag);
            }
        } else if (data.tabLabel == 'Social') {
            $scope.openCircles = false;

            authService.callService({ serviceName: environmentData.services.myLearningService.serviceName, action: trainingService.getCircles, params: { authorID: loginUserID, authorIDType: 1, activityID: activityId } }).then(function (data) {
                if (typeof data !== '' && data.ReturnCode === 0 && typeof data.Content.length !== 'undefined') {
                    $scope.chooseCircleShow = true;
                    $scope.chooseCircleIcon = 'icon ion-chevron-right placeholder-icon';
                    $scope.Circles = data.Content;

                    angular.forEach(data.Content, function (item) {
                        if (item.defaultCircle === 1) {
                            $rootScope.circleId = item.circleID;
                            $scope.circleTitle = 'Circle - ' + item.circleName;
                            console.log(item.circleName);
                        }
                    });
                } else {
                    if (data !== '' && data.ReturnCode === 0 && data.Content !== '') {
                        $scope.chooseCircleShow = false;
                        $rootScope.circleId = data.Content.circleID;
                    }
                }

                $scope.stream = [];
                $scope.skip = 0;
                $scope.existMoreData = true;
                $scope.isLoading = false;
                //$scope.showPost = true;

                streamService.clearStream();

                if (streamService.getCurrentStream().length == 0) {
                    $scope.loadStream();
                }
                else {
                    $scope.stream = streamService.getCurrentStream();
                    $scope.skip = streamService.getCurrentStream().length;
                }
                $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/stream/new-post.html', {
                    scope: $scope
                }).then(function (modal) {
                    $scope.newArticle_modal = modal;
                });

            }, function (error) {
                console.log(error);
                $scope.showLoading = false;
            });
        } else if (data.tabLabel == 'People On Site') {
            saveDropdownValue(2);
            restoreDropdownValue(4);

            $scope.initializeDropdownValue();
            $scope.getDemographicType('4');
            $scope.getPeopleLikeMe($rootScope.peoplekey, activityId, 4);

            if ($scope.peopleOnSite.length == 0) {
                //$scope.initializeDropdownValue();
                //$scope.getDemographicType('4');
                //$scope.getPeopleLikeMe($rootScope.peoplekey, activityId, 4);
                $scope.getPeopleOnSite(activityId, $scope.positionPeopleFlag, '', '');
            }
        } else if (data.tabLabel == 'Materials') {
            if ($scope.meterials.length == 0) {
                $scope.getMeterial(activityId);
            }
        } else if (data.tabLabel == 'Venue') {
            $scope.qCenterLinkVisible = false;

            if ($scope.currentLocation == 'RLC - St. Charles Q Center') {
                $scope.qCenterLinkVisible = true;
                $scope.getSingleFacility(activityId, 1);
            } else if ($scope.currentLocation == 'RLC - Kuala Lumpur Sheraton Imperial') {
                $scope.getSingleFacility(activityId, 737);
            } else if ($scope.currentLocation == 'RLC - Madrid NH Collection Eurobuilding') {
                $scope.getSingleFacility(activityId, 2612);
            } else if ($scope.currentLocation == 'RLC - Bengaluru Marriott Hotel') {
                $scope.getSingleFacility(activityId, 4404);
            } else if ($scope.currentLocation == 'RLC - London Wokefield Park') {
                $scope.getSingleFacility(activityId, 4790);
            }
        } else if (data.tabLabel == 'About' || data.tabLabel == 'Rate' || data.tabLabel == 'About/Rate') {
            $ionicLoading.show();
            if ($scope.isPastSession && !sendAllParVisible) {
                getSurveyLink(activityId);
                getFacultySurveyLink(activityId);

                //get faculty image.
                angular.forEach($scope.facutysForPassedSession, function (faculty) {
                    var eid = faculty.EnterpriseID;
                    faculty.fullName = faculty.lastName + ', ' + faculty.firstName;
                    var cached = localStorageService.get('ACLMOBILE_IMAGE_' + eid);
                    if (cached == null || cached == '') {
                        menuService.getProfileImageModel(eid).then(function (data) {
                            var url = data[0].m_Uri;
                            faculty.imgUrl = url;
                            localStorageService.set('ACLMOBILE_IMAGE_' + eid, url);
                        });
                    } else {
                        faculty.imgUrl = cached;
                    }
                });
            } else {
                $scope.getTrainingDesc(activityId);
            }
        }
    });

    $scope.moreDataCanBeLoaded = function () {
        if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "Participants") {
            return $scope.moreParticipantsData;
        } else if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "People On Site") {
            return $scope.morePeopleData;
        } else {
            return false;
        }
    }
    $scope.loadMore = function () {
        // Participant tab.
        if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "Participants") {
            if ($scope.participantsflag) {
                $scope.getParticipants(activityId, $scope.positionPartFlag, '', '');
            }
            else {
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
            $scope.participantsflag = true;
        };

        // PeopleOnSite tab.
        if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "People On Site") {
            if ($scope.peopleFlag) {
                $scope.getPeopleOnSite(activityId, $scope.positionPeopleFlag, '', '');
            }
            else {
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
            $scope.peopleFlag = true;
        };
    };

    $scope.moreSearchCanBeLoaded = function () {
        if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "Participants") {
            return $scope.moreVenueData;
        } else if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "People On Site") {
            return $scope.morePeopleOnSiteData;
        }
    }
    $scope.loadMoreSearch = function () {
        if (!$scope.searchInprogress) {
            $scope.searchPeople(activityId, $scope.positionSearchFlag, 1);
            $scope.searchPeopleOnSite(activityId, $scope.peopleOnSiteSearchPositionFlag);
        }
    };
    //#region Actions
    /*$scope.$on('navigateToDetail', function (event, data) {
        $scope.description = "";
        $scope.participants = [];
        $scope.faculty = [];
        $scope.Venue = [];
        $scope.singleFacility = [];
        $scope.Schedule = [];
        $scope.ScheduleStartDate = '';
        $scope.meterials = [];
        $scope.boolOpenPeopleLikeMe = false;
        $scope.PeopleLikeMeTitle = 'People Like ME';
        //event.stopPropagation();//prevent the event popup again.
        $scope.init();
    });*/
    function clearData(){
        $scope.description = "";
        $scope.participants = [];
        $scope.faculty = [];
        $scope.Venue = [];
        $scope.singleFacility = [];
        $scope.Schedule = [];
        //$scope.ScheduleStartDate = '';
        $scope.meterials = [];
        $scope.boolOpenPeopleLikeMe = false;
        $scope.PeopleLikeMeTitle = 'People Like ME';
    }
    $scope.init = function () {
        clearData();
        //$scope.$on('$ionicView.loaded', function (e) {
        activityId = $scope.currentTrainingId;
        playabilityValue = $scope.playabilityValue;
        sendAllParVisible = $scope.sendAllParVisible;
        loginUserID = $rootScope.loginUserID;

        if(activityId == undefined || activityId == null){
            activityId = 1294922;
            $scope.currentTrainingId = activityId;
            $scope.currentTrainingDate='Nov 1-8';
            $scope.currentTrainingTitle='Offering of ILC_API_OCT24_2';
        }

        currentTrainingFromDt = $scope.currentTrainingFromDt;
        $scope.isAndroidDevice = device.platform === 'Android' ? true : false;
        if (personalisedMessageData.backViewFlag == 'true'){
            $scope.chooseScheduleTab(2);
        }
        //$scope.noSchedulePlaceHolder= true;
        //$scope.noMeterialPlaceHolder = true;
        //$scope.noFacultyPlaceHolder = true;
        saveDropdownValue(2);
        saveDropdownValue(4);

        $ionicLoading.show();

        $scope.getSchedule(activityId, $scope.ScheduleStartDate ,$scope.ScheduleStartLocalDate);
        $scope.getParticipants(activityId,10,'','');
    }

    $scope.sessionSurvey; $scope.facultySurvey;

    var getSurveyLink = function (activityId) {
        $ionicLoading.show();
        trainingService.getSurveyForSession(activityId).then(
            function (survey) {
                $scope.sessionSurvey = survey;
                $scope.sessionSurveyReady = true;
                $ionicLoading.hide();

            }, function () {
                var msg = 'There was an error get Presenters survey for session of Activity :' + activityId;
                console.log(msg);
                $ionicLoading.hide();
            })
    }
    var getFacultySurveyLink = function (activityId) {
        $ionicLoading.show();
        trainingService.getSurveyForFaculty(activityId).then(
            function (survey) {
                $scope.facultySurvey = survey;
                $scope.facultySurveyReady = true;
                //$ionicLoading.hide();


                //get faculty image.
                if ($scope.faculty.length == 0) {
                    $scope.getFaculty(activityId, $scope.positionFacuFlag);
                }



            }, function () {
                $ionicLoading.hide();
                var msg = 'There was an error get Presenters survey for session of Activity :' + activityId;
                console.log(msg);
                $ionicLoading.hide();
            })
    }

    $scope.openSevey = function (URL) {
        if (!$rootScope.ImpersonateStatus) {
            window.open(URL, '_system', 'location=yes');
            return false;
        }
    };


    $scope.navigateToProfile = function (eid) {
        menuService.getProfiledTAIModel(eid).then(function (data) {
            $rootScope.profileImage = data[0].m_Uri;
        })
        boradcase(data)
    }


    //get description
    $scope.getTrainingDesc = function (activityID) {

        trainingService.getTrainingDesc(activityID).then(
            function (data) {

                var desc = data[0].description;
                //$scope.courseCode = data[0].courseCd;
                while (desc.indexOf('\r\n') >= 0) {
                    desc = desc.replace('\r\n', '<BR/>');
                }
                $scope.description = desc;
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $ionicLoading.hide();
            },
            function (data, status) {

                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $ionicLoading.hide();
            }
        );
    }

    // search in participant page
    $scope.searchPeople = function (activityId, positionFlag, type) {

        //alert('search text = ' + $scope.searchText);
        if ($scope.inSearchProgress) {
            return;
        }
        $scope.inSearchProgress = true;

        if (positionFlag == 0) {
            $ionicLoading.show();
        }

        trainingService.searchPeople(activityId, positionFlag, type, $scope.searchText, '', '').then(
            function (venuedata) {
                //var eid = '';
                $scope.inSearchProgress = false;
                angular.forEach(venuedata, function (profiledata, index, array) {

                    var eid = profiledata.EnterpriseID;
                    profiledata.fullName = profiledata.lastName + ', ' + profiledata.firstName;

                    var cached = localStorageService.get("ACLMOBILE_IMAGE_" + eid);
                    if (cached == null || cached == "") {
                        menuService.getProfileImageModel(eid).then(function (imgedata) {
                            var url = imgedata[0].m_Uri;
                            profiledata.imgUrl = url;
                            localStorageService.set("ACLMOBILE_IMAGE_" + eid, url);
                        });
                    }
                    else {
                        profiledata.imgUrl = cached;
                    }

                    //Get profile infomationf
                    menuService.getProfileInfoModel(profiledata.EnterpriseID).then(function (titledata) {
                        profiledata.standardjobdescr = titledata["CupsProfile"][0].standardjobdescr;
                    });

                    $scope.Venue.push(profiledata);
                });



                if (venuedata.length == null || venuedata.length == 0) {
                    $scope.moreVenueData = false;
                    $scope.noDataShow = true;
                    $scope.noDataText = $scope.searchText;
                    $scope.positionSearchFlag = 0;
                } else if (venuedata.length < 20) {
                    $scope.moreVenueData = false;
                    //$scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                } else {
                    $scope.moreVenueData = true;
                    $scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                }

                //$scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');

                //after search succ, disable the search button. will enable when text change and length >= 3
                $scope.canSearch = false;
            },
            function (venuedata, status2) {
                $scope.inSearchProgress = false;
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    }

    //get participants list
    $scope.getParticipants = function (activityId, positionFlag, DemogCategory, DemogKey) {
        if (positionFlag == 0) {
            $ionicLoading.show();
        }
        authService.callService({ serviceName: environmentData.services.myLearningService.serviceName, action: trainingService.searchPeople, params: { activityId:activityId, ReturnSetFlag:positionFlag, RecordCount:1,SearchStr:'', DemogCategory:DemogCategory, DemogKey:DemogKey} }).then(
            function (data2) {
                //var eid = '';
                angular.forEach(data2, function (data3, index, array) {
                    var eid = data3.EnterpriseID;
                    data3.fullName = data3.lastName + ', ' + data3.firstName;

                    var cached = localStorageService.get("ACLMOBILE_IMAGE_" + eid);
                    if (cached == null || cached == "") {
                        menuService.getProfileImageModel(eid).then(function (data5) {
                            var url = data5[0].m_Uri;
                            data3.imgUrl = url;
                            localStorageService.set("ACLMOBILE_IMAGE_" + eid, url);
                        });
                    }
                    else {
                        data3.imgUrl = cached;
                    }

                    data3.standardjobdescr = data3.CareerLevel;

                    $scope.participants.push(data3);

                });

                if (data2 == null || data2.length < 20) {
                    $scope.moreParticipantsData = false;
                } else {
                    $scope.moreParticipantsData = true;
                }

                $scope.positionPartFlag = $scope.positionPartFlag + 20;
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            },
            function (data2, status2) {
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    };

    //get People Like Me dropdown list
    $scope.getPeopleLikeMe = function (peopleKey, activityId, source) {
        //$scope.peopleLikeMe=[
        //{ text: '1.Total people on site'},
        //{ text: '2.Org Level 2'},
        //{ text: '3.Career Track'}];
        $scope.peopleLikeMe = [];
        trainingService.getPeopleLikeMe(peopleKey, activityId, source).then(
            function (data2) {
                angular.forEach(data2, function (data3) {
                    data3.text = data3.count + ' - ' + data3.label;
                    data3.pplLikeMeDemogCat = data3.pplLikeMeDemogCat;
                    data3.pplLikeMeDemogFK = data3.pplLikeMeDemogFK;
                    $scope.peopleLikeMe.push(data3);
                });
            },
            function (data2, status) {
                var msg = 'System fails to load data of people like me.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
            }
        );
    }

    //get Demographic Type dropdown list
    $scope.getDemographicType = function (source) {
        $scope.demographicType = [];
        trainingService.getDemographicType(source).then(
            function (data2) {
                angular.forEach(data2, function (data3) {
                    data3.label = data3.label;
                    $scope.demographicType.push(data3);
                });
            },
             function (data2, status) {
                 var msg = 'System fails to load data of demographic type.';
                 console.log(msg);
                 $scope.showToast(msg, 'short', 'bottom');
                 $ionicLoading.hide();
             }
        );
    }

    //get Demographics dropdown list
    $scope.getDemographics = function (activityId, source, demogTypeLabel) {

        $ionicLoading.show();
        $scope.demographics = [];
        trainingService.getDemographics(activityId, source, demogTypeLabel).then(
            function (data2) {
                angular.forEach(data2, function (data3) {
                    data3.text = data3.count + ' - ' + data3.pplLikeMeDemogName;
                    data3.pplLikeMeDemogCat = data3.pplLikeMeDemogCat;
                    data3.pplLikeMeDemogFK = data3.pplLikeMeDemogFK;
                    $scope.demographics.push(data3);
                });
                $ionicLoading.hide();
            },
                function (data2, status) {
                    var msg = 'System fails to load data.';
                    console.log(msg);
                    $scope.showToast(msg, 'short', 'bottom');
                    $ionicLoading.hide();
                }
        );
    };

    $scope.boolOpenPeopleLikeMe = false;    // people like me expand flag
    $scope.boolPeopleLikeMeShow = true;     // people like me show flag
    $scope.PeopleLikeMeTitle = 'People Like ME';
    $scope.PeopleLikeMeIcon = 'icon ion-chevron-right placeholder-icon';

    $scope.DemographicTitle = 'Demographic Type';
    $scope.boolOpenDemographic = false;     // Demographic Type expand flag
    $scope.boolDemographicShow = true;      // Demographic Type show flag
    $scope.DemographicIcon = 'icon ion-chevron-right placeholder-icon';

    $scope.DemographicsTitle = '';
    $scope.boolOpenDemographics = false;    // Demographics expand flag
    $scope.boolDemographicsShow = false;      // Demographics show flag
    $scope.DemographicsIcon = 'icon ion-chevron-right placeholder-icon';

    //Expand or merger DemographicType
    $scope.isShowDemographicType = function (value) {
        $scope.boolOpenDemographic = !$scope.boolOpenDemographic;
        if ($scope.boolOpenDemographic == false && value == '') {
            $scope.DemographicIcon = 'icon ion-chevron-right placeholder-icon';
            $scope.boolPeopleLikeMeShow = true;
        }
        else if ($scope.boolOpenDemographic == false && value != '') {
            $scope.DemographicIcon = 'icon ion-chevron-left placeholder-icon';
            $scope.boolPeopleLikeMeShow = false;
        }
        else if ($scope.boolOpenDemographic == true) {
            $scope.DemographicIcon = 'icon ion-chevron-left placeholder-icon';
            $scope.boolPeopleLikeMeShow = false;
        }
        $scope.DemographicTitle = 'Demographic Type';
    }


    //Expand or merger Demographics
    $scope.isShowDemographics = function (value) {
        $scope.boolOpenDemographics = !$scope.boolOpenDemographics;
        if ($scope.boolOpenDemographics == false && value == '') {
            //$scope.DemographicsIcon = 'icon ion-chevron-right placeholder-icon';
            $scope.isShowDemographicType(value);
            $scope.boolDemographicShow = true;

            $scope.boolDemographicsShow = false;
        }
        else if ($scope.boolOpenDemographics == false && value != '') {
            $scope.DemographicsIcon = 'icon ion-chevron-left placeholder-icon';
        }
        else if ($scope.boolOpenDemographics == true) {
            $scope.DemographicsIcon = 'icon ion-chevron-left placeholder-icon';
        }

        if ($scope.DemographicsTitle.indexOf("-") > 0) {
            var tempArr = $scope.DemographicsTitle.split("-");
            $scope.DemographicsTitle = tempArr[0];
        }


    }

    // The event of choice the option of Demographic Type
    $scope.selectDemographicType = function (value, Type) {
        $scope.isShowDemographicType(value);
        $scope.boolDemographicShow = false;

        $scope.boolDemographicsShow = true;
        if (Type == '1')//participants
        {
            $scope.getDemographics(activityId, 1, value);
        }
        if (Type == '2')//PeopleOnSite
        {
            $scope.getDemographics(activityId, 4, value);
        }
        $scope.isShowDemographics(value);
        $scope.DemographicsTitle = value;
    }

    // The event of choice the option of Demographics
    $scope.selectDemographics = function (value, DemogCategory, DemogKey, Type) {
        $scope.isShowDemographics(value);

        if (DemogCategory == 'all') {
            DemogCategory = '';
        }

        if (DemogKey == 'all') {
            DemogKey = '';
        }

        var tempArr = [];
        if (value.indexOf("-") > 0) {
            tempArr = value.split("-");
        }
        $scope.DemographicsTitle = $scope.DemographicsTitle + ' - ' + tempArr[1];
        if (Type == '1')//participants
        {
            $scope.participants = [];
            $scope.getParticipants(activityId, 0, DemogCategory, DemogKey);
        }
        if (Type == '2')//PeopleOnSite
        {
            $scope.peopleOnSite = [];
            $scope.getPeopleOnSite(activityId, 0, DemogCategory, DemogKey);
        }
    }

    //Expand or merger People Like Me
    $scope.isShowPeopleLikeMe = function (value) {
        $scope.boolOpenPeopleLikeMe = !$scope.boolOpenPeopleLikeMe;
        if ($scope.boolOpenPeopleLikeMe == false && value == '') {
            $scope.PeopleLikeMeIcon = 'icon ion-chevron-right placeholder-icon';
            $scope.boolDemographicShow = true;
        }
        else if ($scope.boolOpenPeopleLikeMe == false && value != '') {
            $scope.PeopleLikeMeIcon = 'icon ion-chevron-left placeholder-icon';
            $scope.boolDemographicShow = false;
        }
        else if ($scope.boolOpenPeopleLikeMe == true) {
            $scope.PeopleLikeMeIcon = 'icon ion-chevron-left placeholder-icon';
            $scope.boolDemographicShow = false;
        }
        $scope.PeopleLikeMeTitle = 'People Like ME';
    }

    // Initialize the dropdown list values
    $scope.initializeDropdownValue = function () {
        $scope.boolOpenPeopleLikeMe = false;
        $scope.boolPeopleLikeMeShow = true;
        $scope.PeopleLikeMeTitle = 'People Like ME';
        $scope.PeopleLikeMeIcon = 'icon ion-chevron-right placeholder-icon';
        $scope.DemographicTitle = 'Demographic Type';
        $scope.boolOpenDemographic = false;
        $scope.boolDemographicShow = true;
        $scope.DemographicIcon = 'icon ion-chevron-right placeholder-icon';
    }


    var saveDropdownValue = function (type) {
        if (type == 2) {
            par_boolOpenPeopleLikeMe = $scope.boolOpenPeopleLikeMe;
            par_boolPeopleLikeMeShow = $scope.boolPeopleLikeMeShow;
            par_PeopleLikeMeTitle = $scope.PeopleLikeMeTitle;
            par_PeopleLikeMeIcon = $scope.PeopleLikeMeIcon;
            par_DemographicTitle = $scope.DemographicTitle;
            par_boolOpenDemographic = $scope.boolOpenDemographic;
            par_boolDemographicShow = $scope.boolDemographicShow;
            par_DemographicIcon = $scope.DemographicIcon;
            par_demographics = $scope.demographics;
            par_boolOpenDemographics = $scope.boolOpenDemographics;    // Demographics expand flag
            par_boolDemographicsShow = $scope.boolDemographicsShow;      // Demographics show flag
            par_DemographicsTitle = $scope.DemographicsTitle;
            par_peopleLikeMe = $scope.peopleLikeMe;
        } else if (type == 4) {
            peo_boolOpenPeopleLikeMe = $scope.boolOpenPeopleLikeMe;
            peo_boolPeopleLikeMeShow = $scope.boolPeopleLikeMeShow;
            peo_PeopleLikeMeTitle = $scope.PeopleLikeMeTitle;
            peo_PeopleLikeMeIcon = $scope.PeopleLikeMeIcon;
            peo_DemographicTitle = $scope.DemographicTitle;
            peo_boolOpenDemographic = $scope.boolOpenDemographic;
            peo_boolDemographicShow = $scope.boolDemographicShow;
            peo_DemographicIcon = $scope.DemographicIcon;
            peo_demographics = $scope.demographics;
            peo_boolOpenDemographics = $scope.boolOpenDemographics;    // Demographics expand flag
            peo_boolDemographicsShow = $scope.boolDemographicsShow;      // Demographics show flag
            peo_DemographicsTitle = $scope.DemographicsTitle;
            peo_peopleLikeMe = $scope.peopleLikeMe;
        }
    }

    var restoreDropdownValue = function (type) {
        if (type == 2) {
            $scope.boolOpenPeopleLikeMe = par_boolOpenPeopleLikeMe;
            $scope.boolPeopleLikeMeShow = par_boolPeopleLikeMeShow;
            $scope.PeopleLikeMeTitle = par_PeopleLikeMeTitle;
            $scope.PeopleLikeMeIcon = par_PeopleLikeMeIcon;
            $scope.DemographicTitle = par_DemographicTitle;
            $scope.boolOpenDemographic = par_boolOpenDemographic;
            $scope.boolDemographicShow = par_boolDemographicShow;
            $scope.DemographicIcon = par_DemographicIcon;
            $scope.demographics = par_demographics;
            $scope.boolOpenDemographics = par_boolOpenDemographics;
            $scope.boolDemographicsShow = par_boolDemographicsShow;
            $scope.DemographicsTitle = par_DemographicsTitle;
            $scope.peopleLikeMe = par_peopleLikeMe;
        } else if (type == 4) {
            $scope.boolOpenPeopleLikeMe = peo_boolOpenPeopleLikeMe;
            $scope.boolPeopleLikeMeShow = peo_boolPeopleLikeMeShow;
            $scope.PeopleLikeMeTitle = peo_PeopleLikeMeTitle;
            $scope.PeopleLikeMeIcon = peo_PeopleLikeMeIcon;
            $scope.DemographicTitle = peo_DemographicTitle;
            $scope.boolOpenDemographic = peo_boolOpenDemographic;
            $scope.boolDemographicShow = peo_boolDemographicShow;
            $scope.DemographicIcon = peo_DemographicIcon;
            $scope.demographics = peo_demographics;
            $scope.boolOpenDemographics = peo_boolOpenDemographics;
            $scope.boolDemographicsShow = peo_boolDemographicsShow;
            $scope.DemographicsTitle = peo_DemographicsTitle;
            $scope.peopleLikeMe = peo_peopleLikeMe;
        }
    }

    // The event of choice the option of people like me
    $scope.selectPeopleLikeMe = function (value, DemogCategory, DemogKey, Type) {
        $scope.isShowPeopleLikeMe(value);
        $scope.PeopleLikeMeTitle = 'People Like ME' + ' - ' + value;

        if (DemogCategory == 'all') {
            DemogCategory = '';
        }

        if (DemogKey == 'all') {
            DemogKey = '';
        }

        if (Type == '1')//participants
        {
            $scope.participants = [];
            $scope.getParticipants(activityId, 0, DemogCategory, DemogKey);
        }
        if (Type == '2')//PeopleOnSite
        {
            $scope.peopleOnSite = [];
            $scope.getPeopleOnSite(activityId, 0, DemogCategory, DemogKey);
        }
    }

    // Search in people on site list
    $scope.searchPeopleOnSite = function (activityId, positionFlag) {

        //alert('search text = ' + $scope.searchText);
        if ($scope.searchPeopleOnSiteInProgress) {
            return;
        }
        $scope.searchPeopleOnSiteInProgress = true;

        if (positionFlag == 0) {
            $ionicLoading.show();
        }

        trainingService.getPeopleOnSite(activityId, $scope.searchText, positionFlag, '', '').then(
            function (venuedata) {
                $scope.searchPeopleOnSiteInProgress = false;
                angular.forEach(venuedata, function (profiledata, index, array) {
                    profiledata.fullName = profiledata.lastName + ', ' + profiledata.firstName;

                    var cached = localStorageService.get("ACLMOBILE_IMAGE_" + profiledata.enterpriseID);
                    if (cached == null || cached == "") {
                        menuService.getProfileImageModel(profiledata.enterpriseID).then(function (imgedata) {
                            data3.imgUrl = imgedata[0].m_Uri;
                            localStorageService.set("ACLMOBILE_IMAGE_" + profiledata.enterpriseID, imgedata[0].m_Uri);
                        });
                    }
                    else {
                        data3.imgUrl = cached;
                    }

                    //Get profile infomation
                    menuService.getProfileInfoModel(profiledata.enterpriseID).then(function (titledata) {
                        profiledata.standardjobdescr = titledata["CupsProfile"][0].standardjobdescr;
                    });

                    $scope.Venue.push(profiledata);
                });

                if (venuedata.length == null || venuedata.length == 0) {
                    $scope.moreVenueData = false;
                    $scope.noDataShow = true;
                    $scope.noDataText = $scope.searchText;
                    $scope.peopleOnSiteSearchPositionFlag = 0;
                } else if (venuedata.length < 20) {
                    $scope.moreVenueData = false;
                    //$scope.peopleOnSiteSearchPositionFlag = $scope.peopleOnSiteSearchPositionFlag + 20;
                } else {
                    $scope.moreVenueData = true;
                    $scope.peopleOnSiteSearchPositionFlag = $scope.peopleOnSiteSearchPositionFlag + 20;
                }

                //$scope.peopleOnSiteSearchPositionFlag = $scope.peopleOnSiteSearchPositionFlag + 20;
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');

                //after search succ, disable the search button. will enable when text change and length >= 3
                $scope.canSearch = false;
            },
            function (venuedata, status) {
                $scope.searchPeopleOnSiteInProgress = false;
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    }

    //get People On Site
    $scope.getPeopleOnSite = function (activityId, positionFlag, DemogCategory, DemogKey) {
        if (positionFlag == 0) {
            $ionicLoading.show();
        }

        trainingService.getPeopleOnSite(activityId, '', positionFlag, DemogCategory, DemogKey).then(
                function (data) {
                    angular.forEach(data, function (item, index, array) {
                        item.fullName = item.lastName + ', ' + item.firstName;
                        menuService.getProfileImageModel(item.enterpriseID).then(function (result) {
                            item.imgUrl = result[0].m_Uri;
                        });

                        menuService.getProfileInfoModel(item.enterpriseID, true).then(function (levelResult) {
                            item.standardjobdescr = levelResult["CupsProfile"][0].standardjobdescr;
                        });

                        item.currentTrainingDate = filter('date')(new Date(item.startDtLocal), 'MMM d, y') + ' to ' + filter('date')(new Date(item.endDtLocal), 'MMM d, y');

                        $scope.peopleOnSite.push(item);
                    });

                    if (data == null || data.length < 20) {
                        $scope.morePeopleData = false;
                    } else {
                        $scope.morePeopleData = true;
                    }

                    //if (data.length == null || data.length == 0) {
                    //    $scope.noPeopleonsiteDataShow = true;
                    //}

                    $scope.positionPeopleFlag = $scope.positionPeopleFlag + 20;
                    $ionicLoading.hide();
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                },
                function (data, status) {
                    var msg = 'System fails to load data.';
                    console.log(msg);
                    $scope.showToast(msg, 'short', 'bottom');
                    $ionicLoading.hide();
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }
            );
    }

    //Get faculty list
    $scope.getFaculty = function (activityId, positionFlag) {

        $ionicLoading.show();

        trainingService.searchPeople(activityId, 0, 2, '', '', '').then(
           function (data2) {
               //var eid = '';
               angular.forEach(data2, function (data3, index, array) {
                   var eid = data3.EnterpriseID;
                   data3.fullName = data3.lastName + ', ' + data3.firstName;

                   var cached = localStorageService.get("ACLMOBILE_IMAGE_" + eid);
                   if (cached == null || cached == "") {
                       menuService.getProfileImageModel(eid).then(function (data5) {
                           var url = data5[0].m_Uri;
                           data3.imgUrl = url;
                           localStorageService.set("ACLMOBILE_IMAGE_" + eid, url);
                       });
                   }
                   else {
                       data3.imgUrl = cached;
                   }

                   data3.standardjobdescr = data3.CareerLevel;

                   $scope.faculty.push(data3);
               });
               if ($scope.faculty == null || $scope.faculty.length == 0) {
                   $scope.noFacultyDataShow = true;
               } else {
                   $scope.noFacultyDataShow = false;
                   //$scope.noFacultyPlaceHolder = false;
               }
               $ionicLoading.hide();


           },
           function (data2, status2) {
               //alert('error');
               var msg = 'System fails to load data.';
               console.log(msg);
               $scope.showToast(msg, 'short', 'bottom');
               $ionicLoading.hide();
           }
        );
    }

    //Get venue page info
    $scope.getSingleFacility = function (activityId, facilityId) {


        //var myLatlng = new google.maps.LatLng(37.3000, -120.4833);

        // var mapOptions = {
        //     center: myLatlng,
        //     zoom: 16,
        //     mapTypeId: google.maps.MapTypeId.ROADMAP
        //     };

        //var map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);

        //navigator.geolocation.getCurrentPosition(function(pos) {
        //map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
        //var myLocation = new google.maps.Marker({
        //    position : new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude),
        //    map: map,
        //    title: "My Location"
        //});
        //});

        $ionicLoading.show();



        trainingService.getSingleFacility(activityId, facilityId).then(
            function (facilitydata) {
                $scope.singleFacility = [];

                angular.forEach(facilitydata, function (item) {
                    if (item.city == 'London') {
                        item.city = item.add2;
                    }
                    $scope.singleFacility.push(item);
                });

                trainingService.getRegion().then(
                    function (result) {
                        var resultArray = [];
                        resultArray = result.split(';');
                        if (resultArray[resultArray.length - 1] == 'China') {
                            $scope.googleMapVisible = false;
                        } else {
                            $scope.googleMapVisible = true;
                        }

                        if (resultArray[resultArray.length - 1] == 'United States') {
                            $scope.getFahrenheit();
                        } else {
                            $scope.getCentigrade();
                        }

                        console.log('GPS country: ' + resultArray[resultArray.length - 1]);
                    },
                    function (result, status) {
                        var msg = 'System fails to load data.';
                        console.log(msg);
                        $scope.showToast(msg, 'short', 'bottom');
                    });

                $ionicLoading.hide();
            },
            function (facilitydata, status2) {
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    }

    $scope.getFahrenheit = function () {
        $scope.fontSizeC = 'font-weight: normal';
        $scope.fontSizeF = 'font-weight: bold';
        $scope.getWeatherInfo($scope.singleFacility[0].city, 'f');
    };

    $scope.getCentigrade = function () {
        $scope.fontSizeC = 'font-weight: bold';
        $scope.fontSizeF = 'font-weight: normal';
        $scope.getWeatherInfo($scope.singleFacility[0].city, 'c');
    };

    // Get weather info in venue page
    $scope.getWeatherInfo = function (loc, degree) {
        $scope.weather = [];
        $ionicLoading.show();

        var searchCondition = "select item from weather.forecast where woeid in (select woeid from geo.places(1) where text='" + loc + "') and u='" + degree + "'";
        trainingService.getWeatherInfo(searchCondition).then(
            function (weatherdata) {
                angular.forEach(weatherdata, function (item) {
                    $scope.weather.push(item);
                });

                $scope.weatherCard = true;
                $ionicLoading.hide();
            },
            function (weatherdata, status) {
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    }

    //Get schedule list
    $scope.getSchedule = function (activityId, startdate, startLocalDate) {
        $scope.hideCompleted=[];

        var AuthorIDType;
        $ionicLoading.show();

        if($rootScope.adminFlage){
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1){
            AuthorIDType = 2;
        }

        authService.callService({ serviceName: environmentData.services.myLearningService.serviceName, action: trainingService.getScheduleDetails , params:activityId} ).then(function (data) {
            $ionicLoading.hide();

            if (data != null) {
                var numDate = 0;
                angular.forEach(data["activity"]["day"], function (item, index) {
                    if (item["@count"] == 1) {
                        numDate = index;
                    }
                    if (item["@eventDate"] != '') {
                        //item["@count"] = $scope.addDate(startdate, item["@count"]);
                        //item["@count"] = new Date(item["@eventDate"]);
                        item["@count"] = filter('date')(item["@eventDate"], 'MMM d, y');

                    }
                    else {
                        item["@count"] = '';
                    }

                    var dt = new Date(item['@count']);

                    if (typeof item.event.length !== 'undefined') {
                        angular.forEach(item.event, function (subItem, subIndex) {
                            subItem = scheduleDataProcessing(subItem, dt, startdate, startLocalDate);
                        });
                    }
                    else {
                        item.event = scheduleDataProcessing(item.event, dt, startdate, startLocalDate);
                    }

                });

                $scope.Schedule = data["activity"]["day"];

                if($scope.isCurrent == true){

                    var arr=[];
                    angular.forEach(data["activity"]["day"], function (item, index){
                        arr[index]=new Array();
                        angular.forEach(item.event, function (subItem, subIndex) {
                            arr[index][subIndex]=subItem.isPastState;
                        });
                    });
                    $scope.hideCompleted =arr;

                    if ($scope.pickRule == 1 ||$rootScope.adminFlage == true){
                        var mockDate = filter('date')(new Date(),'MM-dd-yyyy HH:mm:ss', 'UTC')
                        getRollCall(loginUserID, AuthorIDType, activityId, mockDate);
                    }
                }
            }

            if ($scope.Schedule == null || $scope.Schedule.length == 0) {
                $scope.noScheduleDataShow = true;
            }
            else {
                $scope.noScheduleDataShow = false;
                //$scope.noSchedulePlaceHolder = false;
            }
            
            $timeout(function() {
                startPosition();
            }, 500);
        },
        function (data, status) {
            var msg = 'System fails to load data.';
            console.log(msg);
            $scope.showToast(msg, 'short', 'bottom');
            $ionicLoading.hide();
        }
        )




    };

    function scheduleDataProcessing(item, dt, startdate, startLocalDate) {
        var tmpS = item.starttime.split(':'), tmpE = item.endtime.split(':');
        var year = dt.getFullYear(), mon = dt.getMonth(), day = dt.getDate(), startH = tmpS[0], startM = tmpS[1], endH = tmpE[0], endM = tmpE[1];
        var startDt = new Date(year, mon, day, startH, startM, 0, 0);
        var endDt = new Date(year, mon, day, endH, endM, 0, 0);

        //else {
        //    //item.showCurTimeLine = false;
        //}
        //
        //if (isNaN(Date.parse(startDt)) || isNaN(Date.parse(endDt))) {
        //    //item.showAddBtn = false;
        //}
        //else {
        //    //item.showAddBtn = true;
        //}

        if (startdate != '' && startLocalDate != '' && startdate != undefined) {
            //var displayDate = startdate.split('T')[0] + ' ' + item.starttime;
            //var d1 = new Date(startdate);
            //var d2 = new Date(displayDate);
            //$scope.subHour = (d1 - d2) / 1000 / 3600;
            $scope.subHour = (new Date(startdate) - new Date(startLocalDate)) / 1000 / 3600;
        }

        if (!isNaN(Date.parse(startDt)) && !isNaN(Date.parse(endDt))) {
            if (parseInt(tmpS[0]) > parseInt(tmpE[0])) {
                endDt = new Date((endDt / 1000 + 86400) * 1000); //If the start Hour > end Hour , Add one day for End date based on current day.
            }

            startDt.setHours(startDt.getHours() + $scope.subHour);
            endDt.setHours(endDt.getHours() + $scope.subHour);
            var offset = new Date().getTimezoneOffset() / 60;
            startDt.setHours(startDt.getHours() - offset);
            endDt.setHours(endDt.getHours() - offset);
        }

        if (startDt <= new Date() && new Date() <= endDt) {
            item.isCurrentState=true;
            item.isUpcomingState=false;
            item.isPastState=false;
            item.sessionStates="In Progress";
            item.sessionStatesIcons="acc-refresh2";
            //item.showCurTimeLine = true;
            //item.topMarginPercent = filter('number')((new Date() - startDt) / (endDt - startDt), 2) * 100;
        }
        if(startDt > new Date()){
            item.isCurrentState=false;
            item.isUpcomingState=true;
            item.isPastState=false;
            item.sessionStates="";
            item.sessionStatesIcons="";
        }
        if(new Date()> endDt){
            item.isCurrentState=false;
            item.isUpcomingState=false;
            item.isPastState=true;
            item.sessionStates="Completed";
            item.sessionStatesIcons="ion-checkmark-circled";
        }

        return item;
    }

    //Get meterial list
    $scope.getMeterial = function (activityID) {
        $ionicLoading.show();

        trainingService.getMeterialDetails(activityID).then(function (data) {
            $ionicLoading.hide();
            $scope.meterials = [];
            if (data != null) {
                $scope.allMeterials = trainingService.parseMetreialFromHTML(data);
                if ($rootScope.adminFlage == true || $scope.pickRule == true) {
                    $scope.meterials = $scope.allMeterials;
                } else {
                    angular.forEach($scope.allMeterials, function (subItem) {
                        if (subItem.role == 0) {
                            $scope.meterials.push(subItem)
                        }
                    });
                }
            }
            if (typeof $scope.meterials === 'undefined' || !$scope.meterials.length || !$scope.meterials[0]) {
                $scope.noMeterialDataShow = true;
            } else {
                $scope.noMeterialDataShow = false;
                //$scope.noMeterialPlaceHolder = false;
            }
        },
        function (data, status) {
            var msg = 'System fails to load data.';
            console.log(msg);
            $scope.showToast(msg, 'short', 'bottom');
            $ionicLoading.hide();
        }
        )
    };

    // add day count
    $scope.addDate = function (dd, dadd) {
        var a = new Date(dd);
        a = a.valueOf();
        a = a + (dadd - 1) * 24 * 60 * 60 * 1000;
        a = new Date(a);
        return a;
    };


    $scope.sendChatMsg = function (index, type) {
        var address = "";
        if (type == 0) { //participant
            address = $scope.participants[index].eMail;
        }
        else if (type == 1) { //facult
            address = $scope.faculty[index].eMail;
        }
        else if (type == 2) { //people on site
            address = $scope.peopleOnSite[index].eMail;
        }

        $scope.showAlert(address);
    };


    $scope.sendEmail = function (index, type) {

        var address = "";
        if (type == 0) { //participant
            address = $scope.participants[index].eMail;
            //address = 'jun.h.li@accenture.com;qiang.shao@accenture.com';
        }
        else if (type == 1) { //facult
            address = $scope.faculty[index].eMail;
        }
        else if (type == 2) { //people on site
            address = $scope.peopleOnSite[index].eMail;
        }

        var link = "mailto:" + address + "?subject=" + $scope.currentTrainingTitle;
        window.location.href = link;
    };


    $scope.getAllParEmail = function () {
        trainingService.searchPeople(activityId, -1, 1, '', '', '').then(
            function (data2) {
                //var eid = '';
                angular.forEach(data2, function (data3, index, array) {
                    if ($scope.allParAddress == '') {
                        $scope.allParAddress = data3.eMail
                    }
                    else {
                        $scope.allParAddress = $scope.allParAddress + ';' + data3.eMail;
                    }
                });
            },
            function (data2, status2) {
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
    )
    };


    // Send mail for faculty
    $scope.sendAllParEmail = function () {
        var link = "mailto:" + $scope.allParAddress + "?subject=" + $scope.currentTrainingTitle;
        window.location.href = link;
    };


    // An alert dialog
    $scope.showAlert = function (address) {

        if ($scope.isAndroidDevice) {
            var alertPopup = $ionicPopup.alert({
                title: '<h2>Launch Lync</h2>',
                template: 'Tap \'OK\' will copy this contact\'s address automatically and launch Lync, then paste the address to start a chat.',
                okType: 'button-dark' // String (default: 'button-positive')
            });

            alertPopup.then(function (res) {

                $cordovaClipboard.copy(address)
                    .then(function () {
                    }, function () {
                        $console.log('copy faild');
                    });

                //launch the Lync
                var link = "lync://" + address;
                window.location.href = link;
            });
        } else {
            //launch the Lync
            var link = "sip://" + address;
            window.location.href = link;
        }
    };

    $scope.addToCalendar = function (_date, _start, _end, _title, _location, _subHour) {


        //$ionicLoading.show();


        var dt = new Date(_date);
        var tmpS = _start.split(':'), tmpE = _end.split(':');
        var year = dt.getFullYear(), mon = dt.getMonth(), day = dt.getDate(), startH = tmpS[0], startM = tmpS[1], endH = tmpE[0], endM = tmpE[1];
        var start = new Date(year, mon, day, startH, startM, 0, 0),
        end = new Date(year, mon, day, endH, endM, 0, 0);

        if (!isNaN(Date.parse(start)) && !isNaN(Date.parse(end))) {
            if (parseInt(tmpS[0]) > parseInt(tmpE[0])) {
                end = new Date((end / 1000 + 86400) * 1000); //If the start Hour > end Hour , Add one day for End date based on current day.
            }

            start.setHours(start.getHours() + _subHour);
            end.setHours(end.getHours() + _subHour);
            var offset = new Date().getTimezoneOffset() / 60;
            start.setHours(start.getHours() - offset);
            end.setHours(end.getHours() - offset);


            var cal = {
                title: _title,
                location: _location.replace(/(^\s*)|(\s*$)/g, ""), // fix ios crash bug
                notes: '',
                startDate: start,
                endDate: end
            };
            //defaultOptions = angular.extend(defaultOptions, cal);

            $cordovaCalendar.findEvent(cal).then(
                function (result) {
                    if (result.length == 0) {
                        //alert('not found');
                        //add to calendar if not found
                        $cordovaCalendar.createEvent(cal).then(function (result) {

                            schedulePopup();
                            //$ionicLoading.hide();
                            //$scope.showToast('Add to calendar successfully', 'short', 'bottom');
                        }, function (err) {
                            //$ionicLoading.hide();
                            $scope.showToast('There was an error: ' + err, 'short', 'bottom');
                        });
                    }
                    else {
                        $scope.showToast('Event already exist in calendar', 'short', 'bottom');
                    }
                }
                ,
                function (err) {
                    alert('found err');
                }
            );
        }


        //$cordovaCalendar.deleteEvent(cal).then(function (result1) {                    
        //    $cordovaCalendar.createEvent(cal).then(function (result) {
        //        //$ionicLoading.hide();
        //        //$scope.showToast('Add to calendar successfully', 'short', 'bottom');
        //        $timeout(callAtTimeout, 3000);
        //    }, function (err) {
        //        $ionicLoading.hide();
        //        $scope.showToast('There was an error: ' + err, 'short', 'bottom');
        //    });

        //}, function (err1) {                    
        //    $cordovaCalendar.createEvent(cal).then(function (result) {
        //        //$ionicLoading.hide();
        //        //$scope.showToast('Add to calendar successfully', 'short', 'bottom');
        //        $timeout(callAtTimeout, 3000);
        //    }, function (err) {
        //        $ionicLoading.hide();
        //        $scope.showToast('There was an error: ' + err, 'short', 'bottom');
        //    });
        //});


    };
    //get Social data
    $scope.loadStream = function (refresh) {
        $ionicLoading.show();
        $rootScope.circleId = '79dbd409-5edc-46a9-8e92-0006751722fe';
        if (!$rootScope.circleId) {
            $ionicLoading.hide();
        } else {
            streamService.getEventSecured($rootScope.circleId, 10, $scope.skip, refresh).then(
                function (data) {
                    $ionicLoading.hide();
                    console.log(data);
                    var previous = $scope.stream.length;
                    $scope.stream = data;
                    $scope.skip += 10;
                    $scope.existMoreData = $scope.stream.length > previous;

                    if ($scope.stream.length > 0) {
                        $scope.$emit('check-follow', $scope.stream[0].isFollowingGroup);
                    }

                    $ionicScrollDelegate.resize();
                }, function (error) {
                    $scope.existMoreData = false;
                    $ionicLoading.hide();
                    var msg = 'There was an error from getStream:' + $rootScope.circleId;
                    console.log(msg);
                }
            )
        };
    };
    $scope.openNewArticle = function () {
        $scope.newArticle_modal.show();
    };
    $scope.closeNewArticle = function () {
        $scope.newArticle_modal.hide();
    };
    $scope.$on('acc-article-like', function (event, args) {
        //crittercismService.leaveBreadcrumb('Like Article - Id:' + args.eventID);
        streamService.like(args.eventID).then(
            function (data) {
                streamService.likeManagement(args);
            },
            function (error) {
                console.log(error);
                //messagesService.log(error);
                //messagesService.show(constants.messages.stream.like);
            }
        );
        event.stopPropagation();
    });
    $scope.$on('acc-article-share', function (event, args) {
        if (args.userShareThis == 1) { return; }
        //crittercismService.leaveBreadcrumb('Share Article - Id:' + args.eventID);

        streamService.share(args.eventID).then(
            function (data) {
                streamService.shareManagement(args);
            }, function (error) {
                console.log(error);
                //messagesService.log(error);
                //messagesService.show(constants.messages.stream.share);
            }
        );
    });
    $scope.$on('acc-article-comment', function (event, args) {
        streamService.setDetail(args);
        $scope.navigateToState('app.article', { articleId: args.eventID, flag: true }, false);
    });
    $scope.$on('acc-article-navigate', function (event, args) {
        streamService.setDetail(args);
        $scope.navigateToState('app.article', { articleId: args.eventID, flag: false }, false);
    });
    $scope.$on('acc-article-hashtag', function (event, args) {
        $scope.navigateToState('app.discussion', { discussionId: args, circleId: $rootScope.circleId }, false);
    });
    $scope.$on('acc-article-profile', function (event, eid, peopleKey) {
        $scope.navToPeople(eid, peopleKey);
    });
    $scope.$on('post-created', function (event, args) {
        $scope.skip = 0;
        $scope.existMoreData = true;
        streamService.clearStream();
        $scope.stream = [];
        $scope.loadStream(true);
    });
    $scope.doRefresh = function () {

        $scope.$broadcast('scroll.refreshComplete');

        if($scope.isCurrent == true){
            $scope.getSchedule(activityId, $scope.ScheduleStartDate ,$scope.ScheduleStartLocalDate);
        }
        //if (typeof $scope.tabIndex !== "undefined" && $rootScope.tabDict.length !== 0 && typeof $rootScope.tabDict[$scope.tabIndex] !== "" && $rootScope.tabDict[$scope.tabIndex].value === "Social" && $rootScope.circleId) {
        //    $scope.skip = 0;
        //    $scope.existMoreData = true;
        //    streamService.clearStream();
        //    $scope.stream = [];
        //    $scope.loadStream(true);
        //}
    };

    $scope.getVenue = function () {
        $scope.qCenterLinkVisible = false;
        if ($stateParams.city == 'St. Charles') {
            $scope.qCenterLinkVisible = true;
            $scope.getSingleFacility('', 1);
        } else if ($stateParams.city == 'Kuala Lumpur') {
            $scope.getSingleFacility('', 737);
        } else if ($stateParams.city == 'Madrid') {
            $scope.getSingleFacility('', 2612);
        } else if ($stateParams.city == 'Bengaluru') {
            $scope.getSingleFacility('', 4404);
        } else if ($stateParams.city == 'Reading') {
            $scope.getSingleFacility('', 4790);
        }
    };

    function callAtTimeout() {
        //console.log("Timeout occurred");
        $ionicLoading.hide();
        $scope.showToast('Add to calendar successfully', 'short', 'bottom');
    }

    $scope.showToast = function (message, duration, location) {
        $cordovaToast.show(message, duration, location).then(function (success) {
            console.log("The toast was shown");
        }, function (error) {
            console.log("The toast was not shown due to " + error);
        });
    };

    $scope.getLearners = function (index) {
        $scope.FilterLearners = [];
        $scope.parFlag = index;
        var attendanceStatus = null;
        // In Room
        if (index == 1) {
            $scope.filterLearnerTitle = 'In Room';
            $scope.filterLearnerTitleColor = {
                'background-color': '#47A518'
                };
            $scope.filterLearnerTitleIcon = 'learn-Icon-ParticipantsInRoom';
            attendanceStatus = 1;
        // Out of Room
        } else if (index == 2) {
            $scope.filterLearnerTitle = 'Out of Room';
            $scope.filterLearnerTitleColor = {
                'background-color': '#FCB049'
                };
            $scope.filterLearnerTitleIcon = 'learn-Icon-ParticipantsOutofRoom';
            attendanceStatus = -1; // perhaps need 0 ?
        // All Participants
        } else if (index == 3) {
            $scope.filterLearnerTitle = 'All Participants';
            $scope.filterLearnerTitleColor = {
                'background-color': 'black'
                };
            $scope.filterLearnerTitleIcon = 'ion-person';
        }
        $ionicLoading.show();

        // AuthorID, AuthorIDType, ActivityID, AttendanceStatus, StatusTS
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        console.log('getLearners: pickrule-adminflage', $scope.pickRule, $rootScope.adminFlage)
        trainingService.getLearnerByStatus(loginUserID, AuthorIDType, activityId, attendanceStatus, mockDate).then(function (data) {
            angular.forEach(data.Content, function (item) {
                var attendanceDetail = '';
                if (index == 1) {
                    if (item.AttendanceStatus == 1) {
                        if (item.AuthorTypeID == 2) {
                            attendanceDetail = 'Faculty Check-in at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                        } else if (item.AuthorTypeID == 3) {
                            attendanceDetail = 'Sensor Check-in at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                        }

                        $scope.FilterLearners.push({
                            EnterpriseID: item.LearnerID,
                            fullName: item.LastName + ', ' + item.FirstName,
                            attendanceDetail: attendanceDetail,
                            attendanceStatus: item.AttendanceStatus,
                            checkinColor: {
                                'border-color': 'rgb(71, 165, 24)',
                                'background-color': 'rgb(71, 165, 24)'
                            },
                            checkinDisabled: false
                        })
                    }
                } else if (index == 2) {
                    if (item.AttendanceStatus == -1) {
                        attendanceDetail = 'Auto Check-out at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                        $scope.FilterLearners.push({
                            EnterpriseID: item.LearnerID,
                            fullName: item.LastName + ', ' + item.FirstName,
                            attendanceDetail: attendanceDetail,
                            attendanceStatus: item.AttendanceStatus,
                            checkinColor: {
                                'border-color': 'rgb(71, 165, 24)',
                                'background-color': 'rgb(71, 165, 24)'
                            },
                            checkinDisabled: false
                        })
                    }
                    if (item.AttendanceStatus == 0) {
                        attendanceDetail = 'Not Checked-in';
                        $scope.FilterLearners.push({
                            EnterpriseID: item.LearnerID,
                            fullName: item.LastName + ', ' + item.FirstName,
                            attendanceDetail: attendanceDetail,
                            attendanceStatus: item.AttendanceStatus,
                            checkinColor: {
                                'border-color': 'rgb(71, 165, 24)',
                                'background-color': 'rgb(71, 165, 24)'
                            },
                            checkinDisabled: false
                        })
                    }
                } else if (index == 3) {
                    if (item.AttendanceStatus == 1) {
                        if (item.AuthorTypeID == 2) {
                            attendanceDetail = 'Faculty Check-in at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                        } else if (item.AuthorTypeID == 3) {
                            attendanceDetail = 'Sensor Check-in at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                        }
                    } else if (item.AttendanceStatus == -1) {
                        attendanceDetail = 'Auto Check-out at ' + filter('date')(new Date(item.StatusTS), 'h:mm a');
                    } else if (item.AttendanceStatus == 0) {
                        attendanceDetail = 'Not Checked-in';
                    }
                    $scope.FilterLearners.push({
                        EnterpriseID: item.LearnerID,
                        fullName: item.LastName + ', ' + item.FirstName,
                        attendanceDetail: attendanceDetail,
                        attendanceStatus: item.AttendanceStatus,
                        checkinColor: {
                            'border-color': 'rgb(71, 165, 24)',
                            'background-color': 'rgb(71, 165, 24)'
                        },
                        checkinDisabled: false
                    })
                }
            })
            $ionicLoading.hide();
        }).then(function (data) {
            console.log('getLearnerByStatus: ' + data);
            $ionicLoading.hide();
        });

        $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/schedule/sessionParticipant.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.filterLearners_modal = modal;
            modal.show();
        });
    };

    $scope.sessionParticipantTabCss = ['', 'btn-active', ''];
    $scope.getSessionLearners = function (index) {
        $scope.sessionParticipantTabCss = ['', '', ''];
        $scope.sessionParticipantTabCss[index] = 'btn-active';
        $scope.FilterLearners = [];
        $scope.parFlag = index;
        var attendanceStatus = null;
        if (index == 1) {
            attendanceStatus = 1;
        } else if (index == 2) {
            attendanceStatus = -1;
        }

        $ionicLoading.show();
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        console.log('getSessionLearners: pickrule-adminflage', $scope.pickRule, $rootScope.adminFlage)
        trainingService.getLearnerByStatus(loginUserID, AuthorIDType, activityId, attendanceStatus, mockDate).then(function (data) {
            angular.forEach(data.Content, function (item) {
                var checkInTime = '';
                var checkOutTime = '';
                var isNoAction = false;
                if (index == 1) {
                    checkInTime = filter('date')(new Date(item.LatestCheckInTime), 'h:mm a');
                    checkOutTime = filter('date')(new Date(item.LatestCheckOutTime), 'h:mm a');
                } else if (index == 2) {
                    if (item.AttendanceStatus == -1) {
                        checkInTime = filter('date')(new Date(item.LatestCheckInTime), 'h:mm a');
                        checkOutTime = filter('date')(new Date(item.LatestCheckOutTime), 'h:mm a');
                    } else if (item.AttendanceStatus == 0) {
                        isNoAction = true;
                    }
                } else if (index == 3) {
                    if (item.AttendanceStatus == 1) {
                        checkInTime = filter('date')(new Date(item.LatestCheckInTime), 'h:mm a');
                        checkOutTime = filter('date')(new Date(item.LatestCheckOutTime), 'h:mm a');
                    } else if (item.AttendanceStatus == -1) {
                        checkInTime = filter('date')(new Date(item.LatestCheckInTime), 'h:mm a');
                        checkOutTime = filter('date')(new Date(item.LatestCheckOutTime), 'h:mm a');
                    } else if (item.AttendanceStatus == 0) {
                        isNoAction = true;
                    }
                }
                $scope.FilterLearners.push({
                    EnterpriseID: item.LearnerID,
                    fullName: item.LastName + ', ' + item.FirstName,
                    attendanceStatus: item.AttendanceStatus,
                    checkInTime: checkInTime,
                    checkOutTime: checkOutTime,
                    isNoAction: isNoAction,
                    checkinColor: {
                        'border-color': 'rgb(71, 165, 24)',
                        'background-color': 'rgb(71, 165, 24)'
                    },
                    checkinDisabled: false
                });
                //Todo get the group list from Here by Booker

            });
            if (index == 3) parseGroupListForMessage();
            $ionicLoading.hide();
        }, function (data) {
            console.log('getLearnerByStatus: ' + data);
            $ionicLoading.hide();
        });
    };

    $scope.closeSessionParticipant = function () {
        if($scope.subTabsModal != undefined && $scope.subTabsModal != null){
            $scope.subTabsModal.hide();
        }
        $scope.materialsTabCss = [];
        $scope.materialsTabCss[1] = 'materials-tab-selected';
        $scope.filterLearners_modal.hide();
        $scope.$broadcast('scroll.refreshComplete'); 
    };

    $scope.changeToMaterials = function () {
        $scope.filterLearners_modal.hide();
        $scope.materialsTabCss = [];
        $scope.tabContentSelected = [];
        $scope.materialsTabCss[1] = 'materials-tab-selected';
        $scope.tabContentSelected[1] = true;
        if ($scope.meterials.length == 0) {
            $scope.getMeterial(activityId);
        }
    }

    $scope.UpdateAllLearners = function () {
        var index = 3;
        $scope.sessionParticipantTabCss = ['', '', ''];
        $scope.sessionParticipantTabCss[index] = 'materials-tab-selected';
        $scope.FilterLearners = [];
        $scope.parFlag = index;
        var checkInTimeList = [];
        var checkOutTimeList = [];
        var attendanceStatus = null;

        $ionicLoading.show();
        var mockDate = filter('date')(new Date(),'MM-dd-yyyy HH:mm:ss', 'UTC')
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        console.log('UpdateAllLearners: pickrule-adminflage', $scope.pickRule, $rootScope.adminFlage)
        trainingService.getLearnerByStatus(loginUserID, AuthorIDType, activityId, attendanceStatus, mockDate).then(function (data) {
            angular.forEach(data.Content, function (item) {
                var checkInTime = '';
                var checkOutTime = '';
                if (item.AttendanceStatus == 1) {
                    checkInTime = filter('date')(new Date(item.StatusTS), 'h:mm a');
                } else if (item.AttendanceStatus == -1) {
                    checkOutTime = filter('date')(new Date(item.StatusTS), 'h:mm a');
                } else if (item.AttendanceStatus == 0) {
                    checkOutTime = 'Yet to Check-In';
                        }
                        $scope.FilterLearners.push({
                            EnterpriseID: item.LearnerID,
                            fullName: item.LastName + ', ' + item.FirstName,
                            attendanceStatus: item.AttendanceStatus,
                    checkInTime: checkInTime,
                    checkOutTime: checkOutTime,
                            checkinColor: {
                                'border-color': 'rgb(71, 165, 24)',
                                'background-color': 'rgb(71, 165, 24)'
                            },
                            checkinDisabled: false
                        });
                    });
            if (index ==3) parseGroupListForMessage();
            $ionicLoading.hide();
        }, function (data) {
            console.log('getLearnerByStatus: ' + data);
            $ionicLoading.hide();
        });

        getRollCall(loginUserID, AuthorIDType, activityId, mockDate);
    };

    $scope.showDetailPage = function (eid, fullName, attendanceStatus) {
        if (attendanceStatus == 0 || attendanceStatus == -1) {
            $scope.participantActionFullName = fullName;
            $scope.participantActionEid = eid;
            $scope.showCheckOutDetail = false;
            $scope.showCommentContent = false;
            $scope.activityList = [];
            var percent = 100;
            var activityItems = [];
            var specItems = [];
            $ionicLoading.show();
            var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
            var AuthorIDType;
            if ($rootScope.adminFlage) {
                AuthorIDType = 4;
            }
            else if ($scope.pickRule == 1) {
                AuthorIDType = 2;
            }
            trainingService.getAttendanceInfo(loginUserID, AuthorIDType, eid, activityId, mockDate).then(function (data) {
                if (data.Content != null) {
                    angular.forEach(data.Content.Status, function (item) {
                        if (item.AttendanceStatus == 99) {
                            specItems.push(item);
                        } else {
                            activityItems.push(item);
                        }

                        if (item.AttendanceStatus != 0 && item.AttendanceStatus != 99) {
                            $scope.activityList.push({
                                ActivityStatus: item.AttendanceStatus,
                                ActivityTime: filter('date')(new Date(item.StatusTS), 'h:mm a')
                            })
                        }
                    });

                    if (activityItems.length > 0) {
                        if (activityItems[0].AttendanceStatus == 0 || activityItems[0].AttendanceStatus == -1) {
                            $scope.showCheckInButton = true;
                        } else if (activityItems[0].AttendanceStatus == 1) {
                            $scope.showCheckInButton = false;
                        }
                    } else {
                        $scope.showCheckInButton = true;
                    }
                } else {
                    $scope.showCheckInButton = true;
                }

                angular.forEach($scope.activityList, function (result) {
                    if (result.ActivityStatus == 1) {
                        result.ActivityIcon = 'learn-Icon-ParticipantsInRoom';
                        result.ActivityIconColor = {
                            'color': 'rgb(71, 165, 24)'
                        };
                    } else if (result.ActivityStatus == -1) {
                        result.ActivityIcon = 'learn-Icon-ParticipantsOutofRoom';
                        result.ActivityIconColor = {
                            'color': 'rgb(252, 176, 73)'
                        };
                    }
                });

                $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/schedule/detailPage.html', {
                    scope: $scope
                }).then(function (modal) {
                    $scope.detail_modal = modal;
                    modal.show();
                });

                $ionicLoading.hide();
            }, function (data) {
                $ionicLoading.hide();
                console.log('getAttendanceInfo: ' + data);
            });
        }
    };

    $scope.closeDetailPage = function () {
        $scope.detail_modal.hide();
        $scope.UpdateAllLearners();
    }

    $scope.showAttendancePopup = function (eid, attendanceStatus) {
        $scope.participantActionEid = eid;
        var percent = 100;
        $scope.activityList = [];
        var specItems = [];
        $ionicLoading.show();
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC');
        trainingService.getAttendanceInfo(loginUserID, AuthorIDType, eid, activityId, mockDate).then(function (data) {
            if (data.Content != null) {
                angular.forEach(data.Content.Status, function (item) {
                    if (item.AttendanceStatus == 99) {
                        specItems.push(item);
                    }
                });

                if (specItems.length > 0) {
                    $scope.participantActionComment = specItems[0].Comments;
                    if (specItems[0].Participation != null) {
                        percent = specItems[0].Participation;
                    }
                } else {
                    $scope.participantActionComment = '';
                }
            }

            $scope.percent = {
                value: percent,
                options: {
                    floor: 0,
                    ceil: 100,
                    hideLimitLabels: true,
                    showSelectionBar: true,
                    translate: function (value) {
                        return value + '%';
                    }
                }
            };
            $scope.attendancePopup = $ionicPopup.show({
                cssClass: 'checkIn-popup',
                templateUrl: 'conLearning/event/trainingDetail/tabs/schedule/tab.attendancePopup.html',
                scope: $scope
            });
            $ionicLoading.hide();
        }, function (data) {
            $ionicLoading.hide();
            console.log('showAttendancePopup: ' + data);
        });
    }

    $scope.closeAttendancePopup = function () {
        $scope.attendancePopup.close();
    }

    $scope.attendanceConfirm = function (eid) {
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC');
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        trainingService.postAttendanceInfo(loginUserID, AuthorIDType, eid, activityId, $scope.percent.value, $scope.$$childTail.participantActionComment, mockDate).then(function (data) {
            $ionicLoading.hide();
            $scope.attendancePopup.close();
            $scope.showToast('Attendance confirm success!', 'short', 'bottom');
        }, function (data) {
            console.log('attendanceConfirm: ' + data);
            $ionicLoading.hide();
        });
    }

    $scope.showCheckInPopup = function (learnerId, learnerName, index) {
        $scope.participantActionEid = learnerId;
        $scope.fullName = learnerName;
        $scope.checkinPopTime = filter('date')(new Date(), 'HH:mm:ss');
        if ($scope.checkininterval) $interval.cancel($scope.checkininterval);
        $scope.checkininterval = $interval(function () {
            $scope.checkinPopTime = filter('date')(new Date(), 'HH:mm:ss');
        }, 1000);
        $scope.checkinIndex = index;
        $scope.checkinPopup = $ionicPopup.show({
            cssClass: 'checkIn-popup',
            templateUrl: 'conLearning/event/trainingDetail/tabs/schedule/tab.checkInPopup.html',
            scope: $scope
        });
    }

    $scope.checkInPopupAction = function (learnerId, index) {
        $interval.cancel($scope.checkininterval);
        var checkInDT = new Date();
        $ionicLoading.show();
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        trainingService.postCheckIn(loginUserID, AuthorIDType, learnerId, activityId, '', mockDate).then(function (data) {
            if (data.ReturnCode == 0) {
                for (var i = 0; i < $scope.FilterLearners.length; i++) {
                    if (i == index) {
                        $scope.FilterLearners[i].checkinColor = {
                            'border-color': '#cccccc',
                            'background-color': '#cccccc'
                        };
                        $scope.FilterLearners[i].checkinDisabled = true;
                    }
                }
                $scope.UpdateAllLearners();
                $ionicLoading.hide();
                $scope.checkinPopup.close();
                $scope.showToast('Check in success!', 'short', 'bottom');
            }
        }, function (data) {
            console.log('postCheckIn: ' + data);
            $ionicLoading.hide();
        });
    };

    $scope.closeCheckInPopup = function () {
        $interval.cancel($scope.checkininterval);
        $scope.checkinPopup.close();
    };

    $scope.checkInAction = function (eid) {
        var checkInDT = new Date();
        $ionicLoading.show();
        var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
        var AuthorIDType;
        if ($rootScope.adminFlage) {
            AuthorIDType = 4;
        }
        else if ($scope.pickRule == 1) {
            AuthorIDType = 2;
        }
        trainingService.postCheckIn(loginUserID, AuthorIDType, eid, activityId, '', mockDate).then(function (data) {
            if (data.ReturnCode == 0) {
                var checkInContent = [{
                    ActivityTime: filter('date')(new Date(checkInDT), 'h:mm a'),
                    ActivityIcon: 'learn-Icon-ParticipantsInRoom',
                    ActivityIconColor: {
                        'color': 'rgb(71, 165, 24)'
                    }
                }];
                $scope.activityList = checkInContent.concat($scope.activityList);
                $scope.UpdateAllLearners();
                $ionicScrollDelegate.scrollTop();
                $scope.showCheckInButton = !$scope.showCheckInButton;
                $ionicLoading.hide();
                $scope.showToast('Check in success!', 'short', 'bottom');
            }
        }, function (data) {
            console.log(" -- When click to check in,the ReturnCode is " + data.ReturnCode + " -- ");
            $ionicLoading.hide();
        });
        getRollCall(loginUserID, AuthorIDType, activityId, mockDate);
    };

        //Expand or merger Choose Circle
    $scope.isShowCircles = function () {
        $scope.openCircles = !$scope.openCircles;
        if ($scope.openCircles) {
            $scope.chooseCircleIcon = 'icon ion-chevron-left placeholder-icon';
        } else {
            $scope.chooseCircleIcon = 'icon ion-chevron-right placeholder-icon';
    }
    };

    $scope.selectCircle = function (circle) {
        $rootScope.circleId = '';
        $rootScope.circleId = circle.circleID;
        $scope.circleTitle = 'Circle';
        $scope.circleTitle = $scope.circleTitle + ' - ' + circle.circleName;

        $scope.isShowCircles();

        $scope.stream = [];
        $scope.skip = 0;
        $scope.existMoreData = true;
        $scope.isLoading = false;
        //$scope.showPost = true;

        streamService.clearStream();

        if (streamService.getCurrentStream().length == 0) {
            $scope.loadStream(true);
        }
        else {
            $scope.stream = streamService.getCurrentStream();
            $scope.skip = streamService.getCurrentStream().length;
    }
        $ionicModal.fromTemplateUrl('templates/event/stream/new-post.html', {
                scope: $scope
        }).then(function (modal) {
            $scope.newArticle_modal = modal;
    });
    };

        //Materias page and Overview
    $scope.materialsTabCss = ['', 'materials-tab-selected', ''];
    $scope.tabContentSelected = [false, true, false];

    $scope.chooseScheduleTab = function (index) {
        personalisedMessageData.backViewFlag = '';
        $scope.materialsTabCss = [];
        $scope.tabContentSelected = [];
        $scope.materialsTabCss[index] = 'materials-tab-selected';
        $scope.tabContentSelected[index] = true;
        if (index == 1 && $scope.meterials.length == 0) {
            $scope.getMeterial(activityId);
    }
        if (index == 2) {

            $scope.getSessionLearners(3);
            var mockDate = filter('date')(new Date(), 'MM-dd-yyyy HH:mm:ss', 'UTC')
            var AuthorIDType;
            if ($rootScope.adminFlage) {
                AuthorIDType = 4;
            }
            else if ($scope.pickRule == 1) {
                AuthorIDType = 2;
        }
            getRollCall(loginUserID, AuthorIDType, activityId, mockDate);

            if ($scope.filterLearners_modal == undefined || $scope.filterLearners_modal._isShown == false) {
                $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/schedule/sessionParticipant.html', {
                        scope: $scope
                }).then(function (modal) {
                    $scope.filterLearners_modal = modal;
                    modal.show();
            });
        }

    }
    };

    $scope.toggleToMaterials = function (dayTime, date, startTime, endTime, sessionName, location, sessionState, pickrule, fromMain) {
        $scope._dayTime = dayTime;
        $scope._date = filter('dateProcessing') (date);
        $scope._startTime = startTime;
        $scope._endTime = endTime;
        $scope._sessionName = sessionName;
        $scope._location = location;
        $scope._sessionState = sessionState;
        $scope._pickrule = false;
        // $scope._pickRule = $rootScope.adminFlage? true : (pickrule == 1);
        if ($rootScope.adminFlage) {
            $scope._pickrule = true
        } else {
            if (pickrule == 1) {
                $scope._pickrule = true
            }
        }

        $scope._isToday = false;
        var now = filter('date')(new Date(), 'MMM d, yyyy');
        if (date == now) {
            $scope._isToday = true;
        }

        $ionicLoading.hide();
        console.log($rootScope.pickrule)
        // $scope.navigateToState('app.materials','', false);
        if (!fromMain) {
            $ionicModal.fromTemplateUrl('conLearning/event/trainingDetail/tabs/materials/tab.priorities.html', {
                    scope: $scope
            }).then(function (modal) {
                $scope.subTabsModal = modal;
                $scope.chooseScheduleTab(1);
                $scope.subTabsModal.show();
        })
    }
    };

    $scope.materialDownload = function (downloadURL) {
        console.log(downloadURL);
        window.open(downloadURL, '_system', 'location=yes');
    };

    $scope.closeMaterialsModal = function () {
        var sessionData = localStorageService.get('LEARNINGEVENTS_SESSIONDATA');

        if ($scope.subTabsModal != undefined && $scope.subTabsModal != null) {
            $scope.subTabsModal.hide();
            $scope.filterLearners_modal.hide();
        } else {
            $ionicHistory.goBack();
    }

        // angular.forEach(sessionData, function (item) {
        //     if (activityId == item.activityID) {
        //         angular.forEach(item.Session, function (data) {
        //             if (sessionid == data.SessionID) {
        //                 data.Comment = localStorageService.get('LEARNINGEVENTS_SESSIONCOMMENTS' +activityId);
        //             }
        //         })
        //         //item.Comment = $scope.sessionComments;
        //     }
        // });

        // localStorageService.set('LEARNINGEVENTS_SESSIONDATA', sessionData);
    };

        // add navigate to  new PersonalisedMessage, using for both portal
    $scope.navigateToPersonalisedMessage = function (eidItem, flag) {
        var participantItems = [];
        participantItems.push(eidItem); // from CheckIn/Out view, slide a EID and send message, only one eid
        personalisedMessageData.flag = flag;
        personalisedMessageData.backViewFlag = '';
        $scope.filterLearners_modal.hide();
        if ($scope.subTabsModal != undefined && $scope.subTabsModal != null) //from admin page ,material is modal
            $scope.subTabsModal.hide();
        $scope.navigateToState('app.newPersonalisedMessage', {sendToEIDList: participantItems }, true);
    };

    $scope.showCompleted =function (index, event) {
        if ($scope.isCurrent == true) {
            angular.forEach(event, function (item, Iindex) {
                if (item.isPastState == true) {
                    $scope.hideCompleted[index][Iindex] = !$scope.hideCompleted[index][Iindex];
            }
        });
    }
    };
    var parseGroupListForMessage = function () {
        var _array = $scope.FilterLearners;
        angular.forEach(_array, function (item) {
            item.isMatched = true;
            item.isPicked = false;
            item.isGrouped = false;
    });
        personalisedMessageData.activityID = activityId;
        personalisedMessageData.allParticipantsList = _array;
        personalisedMessageData.checkInList = _array.filter(function (obj) {
            return obj.attendanceStatus == 1
    });
        personalisedMessageData.checkOutList = _array.filter(function (obj) {
            return obj.attendanceStatus == -1
    });
        console.log('10/25 ', personalisedMessageData.allParticipantsList);
        console.log('10/25 ', personalisedMessageData.checkInList);
        console.log('10/25 ', personalisedMessageData.checkOutList);
    };

        //scheduleScroll
    var startPosition =function () {
        if ($scope.isCurrent == true && $scope.hideCompleted.length > 0) {
            var isIndex =[];

            angular.forEach($scope.hideCompleted, function (item, index) {
                angular.forEach(item, function (subItem, subIndex) {
                    if (subItem == false) {
                        isIndex.push(index);
                }
            });
        });
            if (isIndex[0] != 0) {
                if ($rootScope.adminFlage == true) {
                    var divH = document.getElementById('scheduleDetailHeader');
                    var divP = document.getElementById('scheduleDetail');
                    var scrollHeight = divH.scrollHeight +Number(divP.scrollHeight) *Number(isIndex[0]);

                    $ionicScrollDelegate.$getByHandle('scheduleScroll').scrollTo(0, scrollHeight, false);
                } else {
                    var divP = document.getElementById('scheduleDetail');
                    var scrollHeight = Number(divP.scrollHeight) *Number(isIndex[0]);

                    $ionicScrollDelegate.$getByHandle('scheduleScroll').scrollTo(0, scrollHeight, false);
            }
        }
    }

    };


        //schedulePopup

    var schedulePopup =function () {

        var schedulePopup = $ionicPopup.show({

                cssClass: 'schedule-popup',
                templateUrl: 'conLearning/event/trainingDetail/tabs/schedule/tab.schedulePopup.html',
                scope: $scope

    });
        schedulePopup.then(function (res) {
            console.log('Tapped!', res);
    });

        $timeout(function () {
            schedulePopup.close();
        }, 2000);

    };

    $scope.init();

    $scope.receiveDataFromMainpage = function () {
        if ($scope.meterials.length == 0) {
            $scope.getMeterial(activityId);
    }
        if (typeof $stateParams == 'object' && !angular.equals({ }, $stateParams)) {
            $scope.toggleToMaterials($stateParams.dayTime, $stateParams.date, $stateParams.startTime, $stateParams.endTime, $stateParams.sessionName, $stateParams.location, $stateParams.sessionState, $stateParams.pickrule, $stateParams.fromMain);
    }
    };

}]);// End PeopleProfileCtrl controller

app.filter('timeProcessing', function () {
    return function (inputTime) {
        var time = null;
        var inputTimeArr = inputTime.split(":");
        if (inputTimeArr[0] < 12) {
            time = inputTime + "AM";
        }
        if (inputTimeArr[0] > 12) {
            inputTimeArr[0] = inputTimeArr[0] - 12;
            time = inputTimeArr[0] + ":" + inputTimeArr[1] + "PM";
        }
        if (inputTimeArr[0] == 12) {
            time = inputTime + "PM";
        }
        return time;
    }
});

app.filter('dateProcessing', function () {
    return function (inputDate) {
        var date = null;
        var inputDateArr = inputDate.split(",");
        inputDateArr = inputDateArr[0].split(" ");

        date = inputDateArr[1] + " " + inputDateArr[0];

        return date;
    }
});