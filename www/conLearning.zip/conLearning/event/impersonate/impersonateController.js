/**
 * Created by jun.h.li on 11/2/2015.
 */
'use strict';
controllers.controller('impersonateController',
    ['$scope', '$rootScope', 'menuService', 'trainingService', 'impersonateService', 'authService', '$ionicActionSheet', 'localStorageService', '$state', '$log', 'ACLMobile.constants', '$stateParams', '$cordovaInAppBrowser', '$ionicLoading', '$sce', '$ionicPopup', '$cordovaClipboard', '$cordovaToast','$filter','$ionicModal',
function ($scope, $rootScope, menuService, trainingService, impersonateService, authService, $ionicActionSheet, localStorageService, $state, $log, aclconst, $stateParams, $cordovaInAppBrowser, $ionicLoading, $sce, $ionicPopup, $cordovaClipboard, $cordovaToast, filter, $ionicModal) {
    $scope.inSearchProgress = false;
    $scope.boolActivities = false;
    $scope.positionSearchFlag = 0;


    $scope.closeSearch = function () {
        $rootScope.search_modal.hide();
        cordova.plugins.Keyboard.close();
        //$state.go("sideMenu.events");


        //$ionicModal.fromTemplateUrl('templates/impersonatesearch.html', {
        //    scope: $scope
        //}).then(function (modal) {
        //    $scope.search_modal = modal;
        //    modal.hide();
        //    //cordova.plugins.Keyboard.show();
        //});

    };

    $scope.performSearch = function () {
        $scope.Venue = [];
        $scope.noDataShow = false;
        $scope.searchPeople($scope.searchText, 0, 3);
        cordova.plugins.Keyboard.close();
        //$scope.getActivityList($scope.searchText);
    };

    $scope.loadMoreSearch = function () {
        if (!$scope.inSearchProgress) {
            $scope.searchPeople($scope.searchText, $scope.positionSearchFlag, 3);
        }
    };

    $scope.moreSearchCanBeLoaded = function () {
        return $scope.moreVenueData;
    };
            
    // search participant & faculty by activityid
    $scope.searchPeople = function (activityId, positionFlag, type) {

        //alert('search text = ' + $scope.searchText);
        if ($scope.inSearchProgress) {
            return;
        }
        $scope.inSearchProgress = true;

        if (positionFlag == 0) {
            $ionicLoading.show({
                templateUrl: 'popup.html', noBackdrop: true, hideOnStateChange: true
            });
        }

        trainingService.searchPeople(activityId, positionFlag, type, '', '', '').then(
            function (venuedata) {

                $scope.inSearchProgress = false;
                angular.forEach(venuedata, function (profiledata, index, array) {

                    var eid = profiledata.EnterpriseID;
                    profiledata.fullName = profiledata.lastName + ', ' + profiledata.firstName;
                    if (profiledata.isInstructor == 1) {
                        profiledata.type = 'Faculty'
                    }
                    if (profiledata.isInstructor == 0) {
                        profiledata.type = 'Participants'
                    }

                    var cached = localStorageService.get("ACLMOBILE_IMAGE_" + eid);
                    if (cached == null || cached == "") {
                        menuService.getProfileImageModel(eid).then(function (imgedata) {
                            var url = imgedata[0].m_Uri;
                            profiledata.imgUrl = url;
                            localStorageService.set("ACLMOBILE_IMAGE_" + eid, url);
                        });
                    }
                    else {
                        profiledata.imgUrl = cached;
                    }

                    $scope.Venue.push(profiledata);
                });



                if (venuedata.length == null || venuedata.length == 0) {
                    $scope.moreVenueData = false;
                    $scope.noDataShow = true;
                    $scope.noDataText = $scope.searchText;
                    $scope.positionSearchFlag = 0;
                } else if (venuedata.length < 20) {
                    $scope.moreVenueData = false;
                    //$scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                } else {
                    $scope.moreVenueData = true;
                    $scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                }

                //$scope.positionSearchFlag = $scope.positionSearchFlag + 20;
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            },
            function (venuedata, status2) {
                $scope.inSearchProgress = false;
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
        );
    };

    // get activity id list
    $scope.getActivityList = function (courseCode) {

        $ionicLoading.show({
            templateUrl: 'popup.html', noBackdrop: true, hideOnStateChange: true
        });

        impersonateService.getSampleSessions(courseCode).then(
            function (data) {
                $scope.activityList = data
                $scope.boolActivities = true;
                $scope.activityListTitle = 'Activities';
                $scope.activityListIcon = 'icon ion-chevron-right placeholder-icon';
                $ionicLoading.hide();
            },
            function (data, status2) {
                var msg = 'System fails to load data.';
                console.log(msg);
                $scope.showToast(msg, 'short', 'bottom');
                $ionicLoading.hide();
            }
        );
    };

    // impersonate select user and view the trainig details
    $scope.impersonate = function (impersonationEid,impersonationPeopleKey, impactivityID) {
        $rootScope.ImpersonateStatus = true; //"End Impersonation";
        
        //Get impersonation token
        impersonateService.getManageModePermission(impersonationEid, impersonationPeopleKey).then(function (data) {
            $rootScope.impersonationToken = data.token;
            console.log('impersonationToken:' + $rootScope.impersonationToken);
        });

        
        // Get impersonation training by activityID
        // Refer to event controller logic
        $scope.location = "";
        trainingService.getTrainingModel().then(
                function (data) {
                    if (data.length == 0) {
                        $scope.showTip();
                    }
                    angular.forEach(data, function (item) {

                        // Check user impersonate activity id 
                        if (item.activityID == impactivityID)
                        {
                            // currently Training
                            if (item.category == 'C') {
                                if (item.PATH != 'USA - Q Center' && item.PATH != 'Kuala Lumpur - Sheraton Imperial' && item.PATH != 'SPP - Madrid High Performance Center' && item.PATH != 'India Learning Center - Bengaluru Marriott Hotel' && item.PATH != 'UIX - Wokefield Park') {
                                    item.imgName = 'blur';
                                    item.showNonPic = false;
                                } else {
                                    item.imgName = item.PATH;
                                    item.showNonPic = true;
                                }
                            }
                                // upcoming Training
                            else if (item.category == 'F') {
                                if (item.PATH != 'USA - Q Center' && item.PATH != 'Kuala Lumpur - Sheraton Imperial' && item.PATH != 'SPP - Madrid High Performance Center' && item.PATH != 'India Learning Center - Bengaluru Marriott Hotel' && item.PATH != 'UIX - Wokefield Park') {
                                    item.imgName = 'blur';
                                    item.showNonPic = false;
                                } else {
                                    item.imgName = item.PATH;
                                    item.showNonPic = true;
                                }
                            }
                                // past training
                            else if (item.category == 'P') {
                                if (item.PATH != 'USA - Q Center' && item.PATH != 'Kuala Lumpur - Sheraton Imperial' && item.PATH != 'SPP - Madrid High Performance Center' && item.PATH != 'India Learning Center - Bengaluru Marriott Hotel' && item.PATH != 'UIX - Wokefield Park') {
                                    item.imgName = 'blur';
                                    item.showNonPic = false;
                                } else {
                                    item.imgName = item.PATH;
                                    item.showNonPic = true;
                                }
                            }

                            $scope.Venue = [];
                            $scope.searchText = '';

                            //alert('1111');
                            //$rootScope.search_modal.hide();
                            // Refer to base controller logic
                            $scope.navigateTraining(item, location);
                            $rootScope.search_modal.hide();
                        }

                    });
                },
                function (data, status) {
                    $scope.showTip();
                    var msg = 'There was an error loading impersonation trainings. Please, try again later';
                    console.log(msg);
                }
            );
    };

    $scope.showToast = function (message, duration, location) {
        $cordovaToast.show(message, duration, location).then(function (success) {
            console.log("The toast was shown");
        }, function (error) {
            console.log("The toast was not shown due to " + error);
        });
    };

}]);// End list controller
